document.addEventListener('DOMContentLoaded', () => {
    const reportInput = document.querySelector('#report_number');
    if (reportInput) {
        reportInput.addEventListener('input', (event) => {
            event.target.value = event.target.value.toUpperCase().replace(/\s+/g, '');
        });
    }

    document.querySelectorAll('.flash').forEach((flash) => {
        window.setTimeout(() => {
            flash.style.opacity = '0';
            flash.style.transition = 'opacity .35s ease';
        }, 4500);
    });
});
